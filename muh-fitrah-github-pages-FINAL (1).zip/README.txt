Muh. Fitrah — Academic Profile

FINAL VERSION

Upload `index.html` and the entire `assets` folder to the root of your GitHub Pages repository.

Important:
- Keep the folder name exactly `assets`.
- Do not upload only index.html; the portrait and academic-profile icons are stored in assets.
- LinkedIn public profile has been updated to:
  https://www.linkedin.com/in/muh-fitrah-b8735615b/
